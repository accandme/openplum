package ch.epfl.data.distribdb.parsing;

/**
 * An operand of a Qualifier.
 * 
 * @author Artyom Stetsenko
 */
public interface Operand {}
