package ch.epfl.ad.milestone2;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import ch.epfl.ad.milestone2.db.DatabaseManager;
import ch.epfl.ad.milestone2.db.ParallelDatabaseManager;

public abstract class AbstractQuery {
	abstract public void run(String[] args) throws SQLException, InterruptedException;
	
	protected List<String> allNodes = new ArrayList<String>();
	
	public DatabaseManager createDatabaseManager(String configFile) throws SQLException {
		DatabaseManager dbManager = new ParallelDatabaseManager();
		
    	Properties prop = new Properties();
    	 
    	try {
            //load a properties file
    		prop.load(new FileInputStream(configFile));
 
    		for (int i = 0; i < Integer.parseInt(prop.getProperty("numberOfNodes")); i++) {
    			
    			dbManager.connect(
    					"node" + i, 
    					prop.getProperty("node" + i + ".jdbc"), 
    					prop.getProperty("node" + i + ".username"), 
    					prop.getProperty("node" + i + ".password"));
    			
    			allNodes.add("node" + i);
    		}
    	} catch (IOException ex) {
    		System.out.println("Invalid config file path or .properties file structure");
    		ex.printStackTrace();
        }
		
		return dbManager;	
	}
	
	public String getFormattedFloat(String value) {
		double doubleValue = Double.parseDouble(value);
		DecimalFormat fourDec = new DecimalFormat("0.0000", new
				DecimalFormatSymbols(Locale.US));
		return fourDec.format(doubleValue);
	}
}
